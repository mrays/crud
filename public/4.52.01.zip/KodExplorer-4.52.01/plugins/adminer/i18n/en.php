<?php
return array(
	'Adminer.meta.title'	=> "Database management",
	'Adminer.meta.desc'		=> " Database management in a single PHP file.<br/><br/>support:MySQL, PostgreSQL, SQLite, MS SQL, Oracle, SimpleDB, Elasticsearch, MongoDB, Firebird"
);