<?php
return array(
	'imageExif.meta.name'			=> '图片EXIF',
	'imageExif.meta.title'			=> '图片EXIF获取',
	'imageExif.meta.desc' 			=> '图片EXIF获取;手机拍摄图片方向自动校正',
	'imageExif.Config.missLib'		=> "缺少php扩展exif,请安装后再试",
);